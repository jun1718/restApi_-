package com.nhnacademy.exam.gateway.adapter.composition;

import org.springframework.stereotype.Component;

@Component
public class CompositionAdapterImpl
    implements CompositionAdapter {
}
