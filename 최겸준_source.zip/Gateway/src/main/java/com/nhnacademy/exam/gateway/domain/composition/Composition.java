package com.nhnacademy.exam.gateway.domain.composition;

public class Composition {
}
