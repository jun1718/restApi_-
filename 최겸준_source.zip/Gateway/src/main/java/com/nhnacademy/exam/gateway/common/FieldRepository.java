package com.nhnacademy.exam.gateway.common;

import lombok.Data;

@Data
public class FieldRepository {
    private String sessionId;
}
