package com.nhnacademy.exam.gateway.vo.member;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;

@Data
@NoArgsConstructor
public class MemberVoCreateComposition {
    private Long memberNo;
    private String id;
}
