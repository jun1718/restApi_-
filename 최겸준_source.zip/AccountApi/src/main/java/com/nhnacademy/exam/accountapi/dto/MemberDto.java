package com.nhnacademy.exam.accountapi.dto;

public interface MemberDto {
    Long getMemberNo();
    String getId();
    String getPw();
    String getEmail();
    String getMemberStatus();
    String getAuthority();
}
