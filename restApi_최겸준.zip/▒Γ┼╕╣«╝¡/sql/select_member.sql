commit;
select * from member;

