package com.nhnacademy.exam.accountapi.dto;

public interface MemberDtoCreateComposition {
    Long getMemberNo();
    String getId();
}
