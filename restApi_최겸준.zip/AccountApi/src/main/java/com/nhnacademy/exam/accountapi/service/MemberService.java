package com.nhnacademy.exam.accountapi.service;

import com.nhnacademy.exam.accountapi.dto.MemberDto;
import com.nhnacademy.exam.accountapi.dto.MemberDtoCreateComposition;
import com.nhnacademy.exam.accountapi.vo.MemberVo;
import java.util.List;

public interface MemberService {
    String createMember(MemberVo member);

    MemberDto findMemberDtoByMemberNo(Long memberNo);

    MemberDto findMemberDtoById(String id);

    MemberDto findMemberDtoByEmail(String email);

    List<MemberDtoCreateComposition> findAllCreateComposition();
}
