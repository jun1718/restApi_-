package com.nhnacademy.exam.gateway.adapter.composition;

public interface CompositionAdapter {
}
