package com.nhnacademy.exam.taskapi.dto.composition;

public interface CompositionDto {
    Long getCompositionNo();
    Long getProjectNo();
    Long getMemberNo();
}
