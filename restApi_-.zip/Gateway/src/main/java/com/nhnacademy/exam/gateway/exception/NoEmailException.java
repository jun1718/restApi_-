package com.nhnacademy.exam.gateway.exception;

public class NoEmailException extends RuntimeException {
    public NoEmailException(String s) {
        super(s);
    }
}
