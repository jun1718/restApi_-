package com.nhnacademy.exam.gateway.service.component;

public interface CompositionService {
}
