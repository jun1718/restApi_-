package com.nhnacademy.exam.gateway.vo.project;

public class ProjectVo {
    private String name;
}
