package com.example.demo;

public class Add {
    public int add(int a, int b) {
        return a + b;
    }
}
